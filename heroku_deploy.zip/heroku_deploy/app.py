#!/usr/bin/python3
import cv2
import json
import face_recognition
from flask import Flask
import numpy as np
from flask_restful import Api,request


app = Flask(__name__)
# app.config['UPLOAD_FOLDER'] = r"C:\Users\Documents"
api = Api(app)


def detectFaces(nparr):
    file = cv2.imdecode(nparr, 0)
    file1 = cv2.imdecode(nparr, 1)
    # load Haar cascade and detect faces
    cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_alt.xml')
    faces = cascade.detectMultiScale(file)
    # print('Found {0} face{1} in {2}'.format(len(faces),'s' if (len(faces) > 1) else '', os.path.basename(file)))

    image_of_person_1 = face_recognition.load_image_file("Person_1.jpg")
    image_of_person_2 = face_recognition.load_image_file("Person_2.jpg")
    image_of_person_3 = face_recognition.load_image_file("Person_3.jpg")
    image_of_person_4 = face_recognition.load_image_file("Nivi2.jpg")
    image_of_person_5 = face_recognition.load_image_file("Person_4.jpg")
    # Face encoding of each person.
    person_1_face_encoding = face_recognition.face_encodings(image_of_person_1)[0]
    person_2_face_encoding = face_recognition.face_encodings(image_of_person_2)[0]
    person_3_face_encoding = face_recognition.face_encodings(image_of_person_3)[0]
    person_4_face_encoding = face_recognition.face_encodings(image_of_person_4)[0]
    person_5_face_encoding = face_recognition.face_encodings(image_of_person_5)[0]
    #a= (person_4_face_encoding - person_5_face_encoding)
    #print(a)

    # list of all known face encodings
    known_face_encodings = [
        person_1_face_encoding,
        person_2_face_encoding,
        person_3_face_encoding,
        person_4_face_encoding,
        person_5_face_encoding
    ]
    # face encodings for any people in the picture
    face_locations = face_recognition.face_locations(file1, number_of_times_to_upsample=2)
    unknown_face_encodings = face_recognition.face_encodings(file1, known_face_locations=face_locations)

    for unknown_face_encoding in unknown_face_encodings:

        # Test
        results = face_recognition.compare_faces(known_face_encodings, unknown_face_encoding, tolerance=0.6)

        name = "Unknown"

        if results[0]:
            name = "Dhoni"
        elif results[1]:
            name = "Raina"
        elif results[2]:
            name = "Virat"
        elif results[3]:
            name = "Nivi"
        elif results[4]:
            name = "AK"

        # print(f"Found {name} in the photo!")
    # if display:
    #     # draw rectangles on faces
    #     for (x, y, w, h) in faces:
    #         cv2.rectangle(file1, (x, y), (x+w, y+h), (0, 255, 0), 3)
    #
    #     # display image with OpenCV
    #     cv2.imshow('Facial Detection', file1)
    #     cv2.waitKey(0)
    #     cv2.destroyAllWindows()

    return (name)
@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        file = request.files['File']
        nparr = np.fromstring(file.read(), np.uint8)
        result=detectFaces(nparr)
        return json.dumps({'Detected Faces':result})

if __name__ == '__main__':
    app.run(debug=True)
